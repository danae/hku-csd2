# jack_module
C++ wrapper for JACK audio, lock free ringbuffer and some examples
